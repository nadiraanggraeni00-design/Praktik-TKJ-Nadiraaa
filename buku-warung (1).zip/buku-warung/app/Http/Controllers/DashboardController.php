<?php

namespace App\Http\Controllers;

use App\Models\Pelanggan;
use App\Models\Kasbon;

class DashboardController extends Controller
{
    public function index()
    {
        $jumlahPelanggan = Pelanggan::count();

        $totalKasbon = Kasbon::where('status', '!=', 'lunas')
            ->sum('jumlah');

        $jumlahBelumLunas = Kasbon::where('status', '!=', 'lunas')
            ->count();

        return view('dashboard', compact(
            'jumlahPelanggan',
            'totalKasbon',
            'jumlahBelumLunas'
        ));
    }
}