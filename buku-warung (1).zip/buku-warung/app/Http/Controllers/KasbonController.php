<?php

namespace App\Http\Controllers;

use App\Models\Kasbon;
use App\Models\Pelanggan;
use Illuminate\Http\Request;

class KasbonController extends Controller
{

    public function index(Request $request)
{
    $query = Kasbon::with('pelanggan')
        ->orderBy('created_at', 'desc');

    $pelanggan = null;

    if ($request->filled('pelanggan_id')) {
        $query->where('pelanggan_id', $request->pelanggan_id);

        $pelanggan = Pelanggan::find($request->pelanggan_id);
    }

    $kasbons = $query->get();

    return view('kasbon.index', compact('kasbons', 'pelanggan'));
}

    public function bayar($id)
{
    $kasbon = Kasbon::findOrFail($id);

    $kasbon->status = 'lunas';
    $kasbon->save();

     return redirect()
        ->route('kasbon.index', ['pelanggan_id' => $kasbon->pelanggan_id])
        ->with('success', 'Kasbon berhasil dibayar.');
}

public function rekap(Request $request)
{
    $query = Pelanggan::with(['kasbons' => function ($query) {
        $query->where('status', '!=', 'lunas');
    }]);

    if ($request->filled('search')) {
        $query->where('nama', 'like', '%' . $request->search . '%');
    }

    $pelanggans = $query->get();

    return view('kasbon.rekap', compact('pelanggans'));
}

public function detail($id)
{
    $pelanggan = Pelanggan::with('kasbons')
        ->findOrFail($id);

    return view('kasbon.detail', compact('pelanggan'));
}

    public function create(Request $request)
{
    $pelanggans = Pelanggan::all();

    $pelanggan = null;

    if ($request->filled('pelanggan_id')) {
        $pelanggan = Pelanggan::findOrFail($request->pelanggan_id);
    }

    return view('kasbon.create', compact('pelanggans', 'pelanggan'));
}

    public function store(Request $request)
    {
        $request->validate([
            'pelanggan_id' => 'required|exists:pelanggans,id',
            'jumlah' => 'required|numeric|min:1',
            'tanggal' => 'required|date',
            'keterangan' => 'nullable|string',
        ]);

        Kasbon::create([
            'pelanggan_id' => $request->pelanggan_id,
            'jumlah' => $request->jumlah,
            'tanggal' => $request->tanggal,
            'keterangan' => $request->keterangan,
            'status' => 'belum lunas',
        ]);

        return redirect()
            ->route('kasbon.index')
            ->with('success', 'Kasbon berhasil dicatat.');
    }

    public function destroy(Kasbon $kasbon)
    {
        $kasbon->delete();

        return redirect()
            ->route('kasbon.index')
            ->with('success', 'Data kasbon berhasil dihapus.');
    }
}