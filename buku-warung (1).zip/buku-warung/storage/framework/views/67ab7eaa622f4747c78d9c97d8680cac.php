<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Kasbon - Buku Warung</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f7fa;
            margin: 0;
            padding: 30px;
        }

        .container {
            max-width: 1100px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
        }

        h1 {
            margin: 0 0 20px;
        }

        .navigasi {
            display: flex;
            gap: 8px;
            margin-bottom: 20px;
        }

        .btn {
            display: inline-block;
            padding: 9px 13px;
            color: white;
            text-decoration: none;
            border-radius: 6px;
        }

        .pelanggan {
            background: #2563eb;
        }

        .rekap {
            background: #7c3aed;
        }

        .success {
            background: #d1fae5;
            color: #065f46;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 6px;
        }

        .total {
            background: #eff6ff;
            border: 1px solid #bfdbfe;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .total span {
            display: block;
            color: #555;
            margin-bottom: 5px;
        }

        .total strong {
            font-size: 24px;
            color: #2563eb;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background: #2563eb;
            color: white;
        }

        .status {
            display: inline-block;
            padding: 5px 8px;
            border-radius: 5px;
            font-size: 13px;
        }

        .belum {
            background: #fee2e2;
            color: #991b1b;
        }

        .lunas {
            background: #d1fae5;
            color: #065f46;
        }

        .bayar {
            background: #059669;
            color: white;
            padding: 6px 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .hapus {
            background: #dc2626;
            color: white;
            padding: 6px 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .aksi {
            display: flex;
            gap: 5px;
            align-items: center;
        }

        .kosong {
            text-align: center;
            padding: 20px;
        }
    </style>
</head>

<body>

<div class="container">

    <?php if($pelanggan): ?>

        <h1>Kasbon <?php echo e($pelanggan->nama); ?></h1>

    <?php else: ?>

        <h1>Data Kasbon</h1>

    <?php endif; ?>

    <div class="navigasi">

        <a href="<?php echo e(route('pelanggan.index')); ?>" class="btn pelanggan">
            Data Pelanggan
        </a>

        <a href="<?php echo e(route('kasbon.rekap')); ?>" class="btn rekap">
            Rekap Kasbon
        </a>

    </div>

    <?php if(session('success')): ?>
        <div class="success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($pelanggan): ?>

        <?php
            $totalKasbon = $kasbons
                ->where('status', '!=', 'lunas')
                ->sum('jumlah');
        ?>

        <div class="total">

            <span>Total Kasbon Belum Lunas</span>

            <strong>
                Rp <?php echo e(number_format($totalKasbon, 0, ',', '.')); ?>

            </strong>

        </div>

    <?php endif; ?>

    <table>

        <thead>
            <tr>
                <th>No</th>
                <th>Pelanggan</th>
                <th>Jumlah</th>
                <th>Tanggal</th>
                <th>Keterangan</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>

        <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $kasbons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kasbon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <tr>

                    <td><?php echo e($loop->iteration); ?></td>

                    <td><?php echo e($kasbon->pelanggan->nama); ?></td>

                    <td>
                        Rp <?php echo e(number_format($kasbon->jumlah, 0, ',', '.')); ?>

                    </td>

                    <td>
                        <?php echo e(\Carbon\Carbon::parse($kasbon->tanggal)->format('d-m-Y')); ?>

                    </td>

                    <td>
                        <?php echo e($kasbon->keterangan ?? '-'); ?>

                    </td>

                    <td>

                        <?php if($kasbon->status === 'lunas'): ?>

                            <span class="status lunas">
                                Lunas
                            </span>

                        <?php else: ?>

                            <span class="status belum">
                                Belum Lunas
                            </span>

                        <?php endif; ?>

                    </td>

                    <td>

                        <div class="aksi">

                            <?php if($kasbon->status !== 'lunas'): ?>

                                <form
                                    action="<?php echo e(route('kasbon.bayar', $kasbon->id)); ?>"
                                    method="POST"
                                    onsubmit="return confirm('Yakin kasbon ini sudah dibayar?')"
                                >

                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>

                                    <button type="submit" class="bayar">
                                        Bayar
                                    </button>

                                </form>

                            <?php endif; ?>

                            <form
                                action="<?php echo e(route('kasbon.destroy', $kasbon->id)); ?>"
                                method="POST"
                                onsubmit="return confirm('Yakin ingin menghapus data kasbon ini?')"
                            >

                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                <button type="submit" class="hapus">
                                    Hapus
                                </button>

                            </form>

                        </div>

                    </td>

                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <tr>

                    <td colspan="7" class="kosong">
                        Belum ada data kasbon.
                    </td>

                </tr>

            <?php endif; ?>

        </tbody>

    </table>

</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\buku-warung\resources\views/kasbon/index.blade.php ENDPATH**/ ?>