<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catat Kasbon - Buku Warung</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f7fa;
            margin: 0;
            padding: 30px;
        }

        .container {
            max-width: 600px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
        }

        h1 {
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-bottom: 6px;
            font-weight: bold;
        }

        input,
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 18px;
            border: 1px solid #ddd;
            border-radius: 6px;
            box-sizing: border-box;
        }

        .pelanggan-terpilih {
            background: #f3f4f6;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            margin-bottom: 18px;
            font-size: 16px;
        }

        .total-preview {
            background: #eff6ff;
            color: #1d4ed8;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 18px;
            font-size: 18px;
            font-weight: bold;
        }

        .btn {
            padding: 10px 15px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }

        .simpan {
            background: #2563eb;
            color: white;
        }

        .kembali {
            background: #ddd;
            color: #333;
            margin-left: 5px;
        }

        .error {
            background: #fee2e2;
            color: #991b1b;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 6px;
        }

        textarea {
        width: 100%;
        padding: 10px;
        margin-bottom: 18px;
        border: 1px solid #ddd;
        border-radius: 6px;
        box-sizing: border-box;
        resize: vertical;
        }
    </style>
</head>

<body>

<div class="container">

    <h1>Catat Kasbon</h1>

    <?php if($errors->any()): ?>

        <div class="error">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

    <?php endif; ?>

    <form action="<?php echo e(route('kasbon.store')); ?>" method="POST">

        <?php echo csrf_field(); ?>

        <?php if($pelanggan): ?>

            <label>Pelanggan</label>

            <div class="pelanggan-terpilih">
                <?php echo e($pelanggan->nama); ?>

            </div>

            <input
                type="hidden"
                name="pelanggan_id"
                value="<?php echo e($pelanggan->id); ?>"
            >

        <?php else: ?>

            <label for="pelanggan_id">
                Pelanggan
            </label>

            <select
                id="pelanggan_id"
                name="pelanggan_id"
                required
            >

                <option value="">
                    -- Pilih Pelanggan --
                </option>

                <?php $__currentLoopData = $pelanggans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option
                        value="<?php echo e($p->id); ?>"
                        <?php echo e(old('pelanggan_id') == $p->id ? 'selected' : ''); ?>

                    >
                        <?php echo e($p->nama); ?>

                    </option>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>

        <?php endif; ?>

        <label for="jumlah">
            Jumlah Kasbon
        </label>

        <input
            type="number"
            id="jumlah"
            name="jumlah"
            min="1"
            step="1"
            value="<?php echo e(old('jumlah')); ?>"
            placeholder="Contoh: 10000"
            required
        >

        <div class="total-preview">

            Total Kasbon:

            Rp <span id="total">0</span>

        </div>

        <label for="tanggal">
            Tanggal
        </label>

        <input
            type="date"
            id="tanggal"
            name="tanggal"
            value="<?php echo e(old('tanggal', date('Y-m-d'))); ?>"
            required
        >

         <label for="keterangan">
            Keterangan
        </label>

    <textarea
            id="keterangan"
            name="keterangan"
            placeholder="Contoh: Rokok + kopi"
            rows="3"
        >
        <?php echo e(old('keterangan')); ?>

    </textarea>

        <button type="submit" class="btn simpan">
            Simpan Kasbon
        </button>

        <a href="<?php echo e(route('kasbon.index')); ?>" class="btn kembali">
            Kembali
        </a>

    </form>

</div>

<script>

    const jumlahInput = document.getElementById('jumlah');
    const total = document.getElementById('total');

    if (jumlahInput) {

        jumlahInput.addEventListener('input', function () {

            const jumlah = Number(this.value) || 0;

            total.textContent =
                jumlah.toLocaleString('id-ID');

        });

    }

</script>

</body>
</html><?php /**PATH C:\xampp\htdocs\buku-warung\resources\views/kasbon/create.blade.php ENDPATH**/ ?>