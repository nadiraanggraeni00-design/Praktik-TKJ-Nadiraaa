<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Pelanggan - Buku Warung</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f7fa;
            margin: 0;
            padding: 30px;
        }

        .container {
            max-width: 600px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
        }

        h1 {
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-bottom: 6px;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 18px;
            border: 1px solid #ddd;
            border-radius: 6px;
            box-sizing: border-box;
        }

        .btn {
            padding: 10px 15px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }

        .simpan {
            background: #2563eb;
            color: white;
        }

        .kembali {
            background: #ddd;
            color: #333;
            margin-left: 5px;
        }

        .error {
            background: #fee2e2;
            color: #991b1b;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 6px;
        }
    </style>
</head>

<body>

<div class="container">

    <h1>Edit Pelanggan</h1>

    <?php if($errors->any()): ?>
        <div class="error">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('pelanggan.update', $pelanggan->id)); ?>" method="POST">

        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <label for="nama">
            Nama Pelanggan
        </label>

        <input
            type="text"
            id="nama"
            name="nama"
            value="<?php echo e(old('nama', $pelanggan->nama)); ?>"
            placeholder="Masukkan nama pelanggan"
            required
        >

        <button type="submit" class="btn simpan">
            Simpan Perubahan
        </button>

        <a href="<?php echo e(route('pelanggan.index')); ?>" class="btn kembali">
            Kembali
        </a>

    </form>

</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\buku-warung\resources\views/pelanggan/edit.blade.php ENDPATH**/ ?>