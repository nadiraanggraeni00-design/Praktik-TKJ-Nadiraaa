<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pelanggan - Buku Warung</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f7fa;
            margin: 0;
            padding: 30px;
        }

        .container {
            max-width: 1000px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
        }

        h1 {
            margin-bottom: 20px;
        }

        .btn-tambah {
            display: inline-block;
            padding: 10px 15px;
            background: #2563eb;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            margin-bottom: 20px;
        }

        .search {
            display: flex;
            gap: 8px;
            margin-bottom: 20px;
        }

        .search input {
            flex: 1;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 6px;
        }

        .search button,

        .search button {
            background: #2563eb;
            color: white;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background: #2563eb;
            color: white;
        }

        .success {
            background: #d1fae5;
            color: #065f46;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 6px;
        }

        .aksi {
            display: flex;
            gap: 5px;
            align-items: center;
        }

        .nama-pelanggan {
            color: #2563eb;
            text-decoration: none;
            font-weight: bold;
        }

        .nama-pelanggan:hover {
            text-decoration: underline;
        }

        .kasbon {
            background: #059669;
            color: white;
            padding: 6px 10px;
            text-decoration: none;
            border-radius: 4px;
        }

        .hapus {
            background: #dc2626;
            color: white;
            padding: 6px 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
    </style>
</head>

<body>

<div class="container">

    <h1>Data Pelanggan</h1>

    @if (session('success'))
        <div class="success">
            {{ session('success') }}
        </div>
    @endif

    <a href="{{ route('pelanggan.create') }}" class="btn-tambah">
        + Tambah Pelanggan
    </a>

    <form action="{{ route('pelanggan.index') }}" method="GET" class="search">

        <input
            type="text"
            name="search"
            value="{{ request('search') }}"
            placeholder="Cari nama pelanggan..."
        >

        <button type="submit">
            Cari
        </button>

    </form>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Pelanggan</th>
                <th>Aksi</th>
            </tr>
        </thead>

        <tbody>

            @forelse ($pelanggans as $pelanggan)

                <tr>

                    <td>{{ $loop->iteration }}</td>

                    <td>
                        <a href="{{ route('kasbon.index', ['pelanggan_id' => $pelanggan->id]) }}"
                           class="nama-pelanggan">
                            {{ $pelanggan->nama }}
                        </a>
                    </td>

                    <td>

                        <div class="aksi">

                            <a href="{{ route('kasbon.create', ['pelanggan_id' => $pelanggan->id]) }}"
                               class="kasbon">
                                + Kasbon
                            </a>

                            <form action="{{ route('pelanggan.destroy', $pelanggan->id) }}"
                                  method="POST"
                                  onsubmit="return confirm('Yakin ingin menghapus pelanggan ini?')">

                                @csrf
                                @method('DELETE')

                                <button type="submit" class="hapus">
                                    Hapus
                                </button>

                            </form>

                        </div>

                    </td>

                </tr>

            @empty

                <tr>
                    <td colspan="3" style="text-align:center;">
                        @if (request('search'))
                            Pelanggan "{{ request('search') }}" tidak ditemukan.
                        @else
                            Belum ada data pelanggan.
                        @endif
                    </td>
                </tr>

            @endforelse

        </tbody>
    </table>

</div>

</body>
</html>