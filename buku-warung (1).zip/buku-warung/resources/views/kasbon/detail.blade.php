<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Kasbon - Buku Warung</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f7fa;
            margin: 0;
            padding: 30px;
        }

        .container {
            max-width: 1000px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
        }

        .info {
            background: #eff6ff;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .kembali {
            display: inline-block;
            background: #2563eb;
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 6px;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background: #2563eb;
            color: white;
        }

        .belum {
            color: #dc2626;
            font-weight: bold;
        }

        .lunas {
            color: #059669;
            font-weight: bold;
        }

        .total {
            margin-top: 20px;
            padding: 15px;
            background: #fee2e2;
            border-radius: 8px;
            font-size: 18px;
            font-weight: bold;
            color: #991b1b;
        }
    </style>
</head>

<body>

<div class="container">

    <a href="{{ route('kasbon.rekap') }}" class="kembali">
        ← Kembali ke Rekap
    </a>

    <h1>Detail Kasbon</h1>

    <div class="info">
        <strong>Nama:</strong> {{ $pelanggan->nama }}<br>
        <strong>No. HP:</strong> {{ $pelanggan->no_hp ?? '-' }}<br>
        <strong>Alamat:</strong> {{ $pelanggan->alamat ?? '-' }}
    </div>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal</th>
                <th>Jumlah</th>
                <th>Keterangan</th>
                <th>Status</th>
            </tr>
        </thead>

        <tbody>
            @forelse ($pelanggan->kasbons as $kasbon)
                <tr>
                    <td>{{ $loop->iteration }}</td>

                    <td>
                        {{ \Carbon\Carbon::parse($kasbon->tanggal)->format('d-m-Y') }}
                    </td>

                    <td>
                        Rp {{ number_format($kasbon->jumlah, 0, ',', '.') }}
                    </td>

                    <td>
                        {{ $kasbon->keterangan ?? '-' }}
                    </td>

                    <td>
                        @if ($kasbon->status === 'lunas')
                            <span class="lunas">Lunas</span>
                        @else
                            <span class="belum">Belum Lunas</span>
                        @endif
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="5" style="text-align:center;">
                        Belum ada riwayat kasbon.
                    </td>
                </tr>
            @endforelse
        </tbody>
    </table>

    @php
        $totalBelumLunas = $pelanggan->kasbons
            ->where('status', '!=', 'lunas')
            ->sum('jumlah');
    @endphp

    <div class="total">
        Total Utang Saat Ini:
        Rp {{ number_format($totalBelumLunas, 0, ',', '.') }}
    </div>

</div>

</body>
</html>