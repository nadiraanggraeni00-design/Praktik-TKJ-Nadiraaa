<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catat Kasbon - Buku Warung</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f7fa;
            margin: 0;
            padding: 30px;
        }

        .container {
            max-width: 600px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
        }

        h1 {
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-bottom: 6px;
            font-weight: bold;
        }

        input,
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 18px;
            border: 1px solid #ddd;
            border-radius: 6px;
            box-sizing: border-box;
        }

        .pelanggan-terpilih {
            background: #f3f4f6;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            margin-bottom: 18px;
            font-size: 16px;
        }

        .total-preview {
            background: #eff6ff;
            color: #1d4ed8;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 18px;
            font-size: 18px;
            font-weight: bold;
        }

        .btn {
            padding: 10px 15px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }

        .simpan {
            background: #2563eb;
            color: white;
        }

        .kembali {
            background: #ddd;
            color: #333;
            margin-left: 5px;
        }

        .error {
            background: #fee2e2;
            color: #991b1b;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 6px;
        }

        textarea {
        width: 100%;
        padding: 10px;
        margin-bottom: 18px;
        border: 1px solid #ddd;
        border-radius: 6px;
        box-sizing: border-box;
        resize: vertical;
        }
    </style>
</head>

<body>

<div class="container">

    <h1>Catat Kasbon</h1>

    @if ($errors->any())

        <div class="error">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>

    @endif

    <form action="{{ route('kasbon.store') }}" method="POST">

        @csrf

        @if ($pelanggan)

            <label>Pelanggan</label>

            <div class="pelanggan-terpilih">
                {{ $pelanggan->nama }}
            </div>

            <input
                type="hidden"
                name="pelanggan_id"
                value="{{ $pelanggan->id }}"
            >

        @else

            <label for="pelanggan_id">
                Pelanggan
            </label>

            <select
                id="pelanggan_id"
                name="pelanggan_id"
                required
            >

                <option value="">
                    -- Pilih Pelanggan --
                </option>

                @foreach ($pelanggans as $p)

                    <option
                        value="{{ $p->id }}"
                        {{ old('pelanggan_id') == $p->id ? 'selected' : '' }}
                    >
                        {{ $p->nama }}
                    </option>

                @endforeach

            </select>

        @endif

        <label for="jumlah">
            Jumlah Kasbon
        </label>

        <input
            type="number"
            id="jumlah"
            name="jumlah"
            min="1"
            step="1"
            value="{{ old('jumlah') }}"
            placeholder="Contoh: 10000"
            required
        >

        <div class="total-preview">

            Total Kasbon:

            Rp <span id="total">0</span>

        </div>

        <label for="tanggal">
            Tanggal
        </label>

        <input
            type="date"
            id="tanggal"
            name="tanggal"
            value="{{ old('tanggal', date('Y-m-d')) }}"
            required
        >

         <label for="keterangan">
            Keterangan
        </label>

    <textarea
            id="keterangan"
            name="keterangan"
            placeholder="Contoh: Rokok + kopi"
            rows="3"
        >
        {{ old('keterangan') }}
    </textarea>

        <button type="submit" class="btn simpan">
            Simpan Kasbon
        </button>

        <a href="{{ route('kasbon.index') }}" class="btn kembali">
            Kembali
        </a>

    </form>

</div>

<script>

    const jumlahInput = document.getElementById('jumlah');
    const total = document.getElementById('total');

    if (jumlahInput) {

        jumlahInput.addEventListener('input', function () {

            const jumlah = Number(this.value) || 0;

            total.textContent =
                jumlah.toLocaleString('id-ID');

        });

    }

</script>

</body>
</html>