<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Kasbon - Buku Warung</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f7fa;
            margin: 0;
            padding: 30px;
        }

        .container {
            max-width: 1100px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
        }

        h1 {
            margin: 0 0 20px;
        }

        .top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
            margin-bottom: 20px;
        }

        .kembali {
            background: #6b7280;
            color: white;
            padding: 9px 13px;
            text-decoration: none;
            border-radius: 6px;
        }

        .search {
            display: flex;
            gap: 8px;
            margin-bottom: 20px;
        }

        .search input {
            flex: 1;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 6px;
        }

        .search button,
        .reset {
            padding: 10px 15px;
            border: none;
            border-radius: 6px;
            text-decoration: none;
            cursor: pointer;
        }

        .search button {
            background: #2563eb;
            color: white;
        }

        .reset {
            background: #6b7280;
            color: white;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background: #2563eb;
            color: white;
        }

        .status {
            display: inline-block;
            padding: 6px 9px;
            border-radius: 5px;
            font-size: 13px;
        }

        .belum {
            background: #fee2e2;
            color: #991b1b;
        }

        .tidak-ada {
            background: #d1fae5;
            color: #065f46;
        }

        .lihat {
            background: #059669;
            color: white;
            padding: 7px 10px;
            text-decoration: none;
            border-radius: 5px;
        }

        .kosong {
            text-align: center;
            padding: 20px;
        }
    </style>
</head>

<body>

<div class="container">

    <div class="top">
        <h1>Rekap Kasbon</h1>

        <a href="{{ route('kasbon.index') }}" class="kembali">
            ← Data Kasbon
        </a>
    </div>

    <form action="{{ route('kasbon.rekap') }}" method="GET" class="search">

        <input
            type="text"
            name="search"
            value="{{ request('search') }}"
            placeholder="Cari nama pelanggan..."
        >

        <button type="submit">
            Cari
        </button>

        <a href="{{ route('kasbon.rekap') }}" class="reset">
            Reset
        </a>

    </form>

    <table>

    <thead>
        <tr>
            <th>No</th>
            <th>Nama Pelanggan</th>
            <th>Total Kasbon</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>
    </thead>

    <tbody>

        @forelse ($pelanggans as $pelanggan)

            @php
                $totalKasbon = $pelanggan->kasbons->sum('jumlah');
            @endphp

            <tr>

                <td>{{ $loop->iteration }}</td>

                <td>
                    {{ $pelanggan->nama }}
                </td>

                <td>
                    <strong>
                        Rp {{ number_format($totalKasbon, 0, ',', '.') }}
                    </strong>
                </td>

                <td>

                    @if ($totalKasbon > 0)

                        <span class="status belum">
                            Belum Lunas
                        </span>

                    @else

                        <span class="status tidak-ada">
                            Tidak Ada Utang
                        </span>

                    @endif

                </td>

                <td>

                    <a
                        href="{{ route('kasbon.index', ['pelanggan_id' => $pelanggan->id]) }}"
                        class="lihat"
                    >
                        Lihat Kasbon
                    </a>

                </td>

            </tr>

        @empty

            <tr>
                <td colspan="5" class="kosong">
                    Tidak ada data pelanggan.
                </td>
            </tr>

        @endforelse

    </tbody>

</table>

</div>

</body>
</html>