<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="manifest" href="{{ asset('manifest.json') }}">
    <meta name="theme-color" content="#2563eb">

    <title>Beranda - Buku Warung</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f7fa;
            margin: 0;
            padding: 30px;
        }

        .container {
            max-width: 1000px;
            margin: auto;
        }

        h1 {
            margin-bottom: 5px;
        }

        .subtitle {
            color: #666;
            margin-bottom: 25px;
        }

        .menu {
            display: flex;
            gap: 10px;
            margin-bottom: 25px;
        }

        .menu a {
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 6px;
            background: #2563eb;
            color: white;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }

        .card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        .card h3 {
            margin-top: 0;
            color: #555;
        }

        .angka {
            font-size: 28px;
            font-weight: bold;
            margin-top: 10px;
            color: #2563eb;
        }

        .utang {
            color: #dc2626;
        }

        .belum-lunas {
            color: #d97706;
        }
    </style>
</head>

<body>

<div class="container">

    <h1>Beranda Buku Warung</h1>

    <p class="subtitle">
        Ringkasan data kasbon Warung Bapak Agung
    </p>

    <div class="menu">
        <a href="{{ route('pelanggan.index') }}">
            Data Pelanggan
        </a>

        <a href="{{ route('kasbon.rekap') }}">
            Rekap Kasbon
        </a>
    </div>

    <div class="cards">

        <div class="card">
            <h3>Total Pelanggan</h3>

            <div class="angka">
                {{ $jumlahPelanggan }}
            </div>
        </div>

        <div class="card">
            <h3>Total Kasbon Belum Lunas</h3>

            <div class="angka utang">
                Rp {{ number_format($totalKasbon, 0, ',', '.') }}
            </div>
        </div>

        <div class="card">
            <h3>Kasbon Belum Lunas</h3>

            <div class="angka belum-lunas">
                {{ $jumlahBelumLunas }}
            </div>
        </div>

    </div>

</div>
<script>
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', function () {
            navigator.serviceWorker.register('/sw.js');
        });
    }
</script>
</body>
</html>