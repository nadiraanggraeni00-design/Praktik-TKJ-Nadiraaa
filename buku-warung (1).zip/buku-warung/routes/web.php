<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PelangganController;
use App\Http\Controllers\KasbonController;
use App\Http\Controllers\DashboardController;

Route::get('/', [DashboardController::class, 'index'])
    ->name('dashboard');

Route::resource('pelanggan', PelangganController::class);

Route::get('/kasbon/rekap', [KasbonController::class, 'rekap'])
    ->name('kasbon.rekap');

Route::get('/kasbon/rekap/{id}', [KasbonController::class, 'detail'])
    ->name('kasbon.detail');

Route::patch('/kasbon/{id}/bayar', [KasbonController::class, 'bayar'])
    ->name('kasbon.bayar');

Route::resource('kasbon', KasbonController::class);